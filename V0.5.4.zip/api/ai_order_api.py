"""AiOrderApiMixin — AI 제공자 우선순위(드래그 재정렬) 저장/조회.

고객사·프로파일과 무관한 앱 전역 설정이다(core/app_settings.py 참고).
"""
import os

from core.app_settings import ai_order_path
from core.atomic_io import dump_yaml_atomic

DEFAULT_AI_ORDER = [
    {"id": "cloud_apis", "label": "클라우드 API", "desc": "등록된 API 키를 체크된 순서대로 시도", "icon": "cloud"},
    {"id": "local", "label": "로컬 NPU (Gemma/Lemonade)", "desc": "http://localhost:13305", "icon": "memory"},
    {"id": "rule_based", "label": "규칙기반", "desc": "항상 사용 가능(최종 안전망)", "icon": "rule"},
]


class AiOrderApiMixin:
    def get_ai_settings(self):
        import yaml
        if not os.path.exists(ai_order_path()):
            return {"order": [p["id"] for p in DEFAULT_AI_ORDER], "providers": DEFAULT_AI_ORDER}
        with open(ai_order_path(), encoding="utf-8") as f:
            cfg = yaml.safe_load(f) or {}
        order = cfg.get("order") or [p["id"] for p in DEFAULT_AI_ORDER]
        by_id = {p["id"]: p for p in DEFAULT_AI_ORDER}
        providers = [by_id[i] for i in order if i in by_id]
        for p in DEFAULT_AI_ORDER:
            if p["id"] not in order:
                providers.append(p)
        return {"order": [p["id"] for p in providers], "providers": providers}

    def save_ai_settings(self, order):
        import yaml
        dump_yaml_atomic({"order": list(order)}, ai_order_path())
        return True
